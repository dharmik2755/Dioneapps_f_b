<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-P0J7Q536GM"></script>
    <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'G-P0J7Q536GM');
    </script>
    <meta name="keywords" content="Mobile Application and Best Web development Company in India, Apps and Web Design Company in India, Web and app Service"/>
    <meta name="description" content="Dioneapps, a leading Mobile & Web Development Company in India and can effortlessly turn a project idea into reality with our superior custom development services.">
    
    <!-- End Google tag (gtag.js) -->
    <link rel="canonical" href="https://www.dioneapps.com/" />

    <title>DioneApps – IT company</title>
    <!-- link css -->
    
    
        
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css" />
    
    <link href="<?php echo e(url('asset/css/counterpanel.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('asset/css/style.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(url('assets/images/logo.png')); ?>" rel="shortcut icon" type="images/ico.ico">

    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

    <!-- font awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" />

    
    <link rel="stylesheet" href="<?php echo e(url('asset/css/lightbox.min.css')); ?>">
    <script src="<?php echo e(url('asset/js/lightbox-plus-jquery.min.js')); ?>"></script>

    
    <link rel="stylesheet" href="<?php echo e(url('asset/css/about_scroller.css')); ?>">

</head>

<body>
    <div class="lines">
        <div class="header_top sticky">
            <div class="container header_container">
                <div class="header_top-wrapper">
                    <div class="header_logo">
                        <a href="<?php echo e(url('/')); ?>">
                            <img src="<?php echo e(url('asset/images/final-logo.svg')); ?>" alt="Dioneapp Logo">
                        </a>
                    </div>
                    <div class="menu_burger">
                        <span></span>
                    </div>
                    <nav class="menu">
                        <ul class="menu_list">
                            <li class="<?php if ($_SERVER['REQUEST_URI'] == '/') {
                                echo 'menu_list-item active_page';
                            } else {
                                echo 'menu_list-item';
                            } ?>">
                                <a href="<?php echo e(url('/')); ?>">Home</a>
                            </li>
                            <li class="menu_list-item"><a href="<?php echo e(url('/about')); ?>">About Us</a> </li>
                            <li class="menu_list-item"><a href="<?php echo e(url('/service')); ?>">Service</a> </li>
                            <li class="menu_list-item"><a href="<?php echo e(url('/portfolio')); ?>">Portfolio</a> </li>
                            
                            <li class="menu_list-item"><a href="<?php echo e(url('/career')); ?>">Career</a> </li>
                            <li class="menu_list-item"><a href="<?php echo e(url('/contactus')); ?>">Contact Us</a> </li>
                            
                        </ul>
                    </nav>
                    

                </div>
            </div>
        </div>
    </div>
<?php /**PATH D:\xampp\htdocs\laravel\Dioneapps_f_b\resources\views/user_header.blade.php ENDPATH**/ ?>