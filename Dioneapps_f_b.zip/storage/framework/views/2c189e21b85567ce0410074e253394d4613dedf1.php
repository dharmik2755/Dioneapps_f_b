<?php echo $__env->make('user_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('main-section'); ?>

<?php echo $__env->make('user_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\Dioneapps_f_b\resources\views/main.blade.php ENDPATH**/ ?>