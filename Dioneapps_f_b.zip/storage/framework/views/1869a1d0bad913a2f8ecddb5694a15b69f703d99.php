


<?php $__env->startSection('main-section'); ?>
    
    <!-- start slider -->
    
    <!-- slider end -->

    <!-- start slider -->
    <section class="page_top slider_page_top ">
        <div class="header_main">
            <div class="container">
                <div class="page_top-wrapper sack_wrapper home_slider_main">
                    <?php $__currentLoopData = $home_slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="home_slider_box">
                            <div class="page_top-left slider_left">
                                <div class="header_main-title slider_title">
                                    <h1>
                                        <?php echo e($hs->title); ?>

                                    </h1>
                                </div>
                                <div class="slider_description">
                                    <p><?php echo e($hs->description); ?></p>
                                </div>
                                <a href="<?php echo e(route('about.page')); ?>" class="header_main-btn btn">
                                    Learn More
                                </a>
                            </div>
                            <div class="page_top-right slider_right">
                                <img src="<?php echo e(URL('upload/' . $hs->image)); ?>" class="page_top-title slider_img" alt="slider image">
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <a href="#services" class="scroll">
            <img src="https://smav.com.ua/images/scroll.svg" alt="">
        </a>
    </section>
    <br>
    <br>
    <!-- slider end -->


    <!-- Services  start -->
    <?php
    $i = 1;
    $n = 2;
    ?>
    <?php $__currentLoopData = $mobile_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php 
        if($i % $n != 0)
        { ?>
        <section class="brif" id="services">
            <div class="container">
                <div class="brif_wrapp">
                    <div class="brif_content" data-aos="fade-right">
                        <div class="brif_title title">
                            <?php echo e($md->title); ?>

                        </div>
                        <div class="brif_text text">
                        </div>
                        <div class="brif_info">
                            <div class="brif_info-text text">
                                <?php echo e($md->description); ?>

                            </div>
                        </div>
                        <a href="<?php echo e(url('development/' . $md->special_id)); ?>" class="brif_btn new_btn">
                            Explore
                        </a>
                    </div>
                    <div class="brif_img_size" data-aos="fade-left" data-aos-delay="500">
                        <img src="<?php echo e(URL('upload/' . $md->image1)); ?>" alt="">
                    </div>
                </div>
            </div>
        </section>
        <?php
        } 
        else 
        { ?>
        <section class="brif" id="services">
            <div class="container">
                <div class="brif_wrapp">
                    <div class="brif_content-left" data-aos="fade-left">
                        <div class="brif_title title">
                            <?php echo e($md->title); ?>

                        </div>
                        <div class="brif_text text">
                        </div>
                        <div class="brif_info">
                            <div class="brif_info-text text">
                                <?php echo e($md->description); ?>

                            </div>
                        </div>
                        <a href="<?php echo e(url('development/' . $md->special_id)); ?>" class="brif_btn new_btn">
                            Explore
                        </a>
                    </div>
                    <div class="brif_img_size-left" data-aos="fade-right" data-aos-delay="500">
                        <img src="<?php echo e(URL('upload/' . $md->image1)); ?>" alt="">
                    </div>
                </div>
            </div>
        </section>
        <?php 
        } 
        $i = $i + 1; 
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- End Services -->

    <!-- start STAGES OF WORK -->
    <section class="stages" data-aos="fade-up">
        <div class="container">
            <?php $__currentLoopData = $stages_of_work_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sowd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="support_title title">
                    <?php echo e($sowd->title); ?>

                </div>
                <div class="support_text text">
                    <?php echo e($sowd->sub_title); ?>

                </div>
                <div class="stages_wrapper" data-aos="fade" data-aos-delay="300">
                    <div class="stages_item">
                        <div class="stages_item-title">
                            <?php echo e($sowd->stages1); ?>

                        </div>
                        <div class="stages_item-text">
                            <?php echo e($sowd->description1); ?>

                        </div>
                    </div>
                    <div class="stages_item">
                        <div class="stages_item-title">
                            <?php echo e($sowd->stages2); ?>

                        </div>
                        <div class="stages_item-text">
                            <?php echo e($sowd->description2); ?>

                        </div>
                    </div>
                    <div class="stages_item">
                        <div class="stages_item-title">
                            <?php echo e($sowd->stages3); ?>

                        </div>
                        <div class="stages_item-text">
                            <?php echo e($sowd->description3); ?>

                        </div>
                    </div>
                    <div class="stages_item">
                        <div class="stages_item-title">
                            <?php echo e($sowd->stages4); ?>

                        </div>
                        <div class="stages_item-text">
                            <?php echo e($sowd->description4); ?>

                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
    <!-- End STAGES OF WORK -->

    <!-- start About Us -->
    <section class="brif">
        <div class="container">
            <div class="brif_wrapp">
                <?php $__currentLoopData = $about_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="brif_content" data-aos="fade-right">
                        <div class="brif_title title">
                            <?php echo e($ad->title); ?>

                        </div>
                        <div class="brif_text text">
                            <?php echo e($ad->sub_title); ?>

                        </div>
                        <div class="brif_info">
                            <div class="brif_info-text text">
                                <?php echo e($ad->description); ?>

                            </div>
                        </div>
                        <a href="<?php echo e(route('about.page')); ?>" class="brif_btn btn">
                            Learn More
                        </a>
                    </div>
                    <div class="brif_img" data-aos="fade-left" data-aos-delay="500">
                        <img src="<?php echo e(URL('upload/' . $ad->image)); ?>" alt="">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- End About Us -->

    
    
    

    <!-- counter penal -->
    
    <!-- end counter penal -->



    
    <section>
        <div class="container">
            <div class="reviews_title title">
                We are specialized in
            </div>
            <div class="reviews_text text">
            </div>
        </div>
        <div class="slider_infi">
            <div class="slide_infinite-track">
                <?php $__currentLoopData = $specialized; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $special): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="slide_infinite">
                        <img src="<?php echo e(URL('upload/' . $special->image)); ?>" height="100" width="150" alt="">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <?php $__currentLoopData = $specialized; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $special): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="slide_infinite">
                        <img src="<?php echo e(URL('upload/' . $special->image)); ?>" height="100" width="150" alt="">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    

    <!-- start our satisfied clients -->
    <section class="reviews">
        <div class="container">
            <div class="reviews_title title">
                Our Satisfied Clients
            </div>
            <div class="reviews_text text">
            </div>
            <div class="reviews_slider" data-aos="fade-down">
                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="slider_wrapper">
                        <div class="slider_item slider_item-left">
                            <div class="slider_item-top">
                                <div class="slider_item-img client_position">
                                    <img src="<?php echo e(URL('upload/' . $cs->image)); ?>" alt="">
                                </div>
                                <div class="slider_item-fio client_left">
                                    <div class="slider_item-name ">
                                        <?php echo e($cs->name); ?>

                                    </div>
                                    <div class="slider_item-prof ">
                                        <?php echo e($cs->profession); ?>, <?php echo e($cs->information); ?>

                                    </div>
                                </div>
                            </div>

                            <div class="slider_item-text">
                                <?php echo e($cs->description); ?>

                            </div>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
        </div>
    </section>
    <!-- Our Satisfied Clients end -->
<?php $__env->stopSection(); ?>






<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\Dioneapps_f_b\resources\views/index.blade.php ENDPATH**/ ?>