 <!-- start footer -->
 <footer class="footer">
     <div class="footer_bottom">
         <div class="container">
             <div class="footer_bottom-wrapper">
                 <!-- start footer DIONEAPPS -->
                 <div class="footer_bottom-item" <?php if ($_SERVER['REQUEST_URI'] != '/portfolio') {
                     echo 'data-aos="fade-up"';
                 } ?>>
                     <?php $__currentLoopData = $footer_first; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ffuo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <div class="bottom-item_title">
                             <?php echo e($ffuo->title); ?>

                         </div>
                         <div class="bottom-item_subtitle">
                             <?php echo e($ffuo->description); ?>

                         </div>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </div>
                 <!-- end footer DIONEAPPS -->

                 <!-- start footer Our services -->
                 <div class="footer_bottom-item item_none" <?php if ($_SERVER['REQUEST_URI'] != '/portfolio') {
                     echo 'data-aos="fade-up" data-aos-delay="200"';
                 } ?>>
                     <div class="bottom-item_title">
                         OUR SERVICE
                     </div>
                     <ul class="bottom-item_list">
                         <?php $__currentLoopData = $specializ_id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <li>
                                 <a class="footer_text text_transform"
                                     href="<?php echo e(url('/development/' . $sd->id)); ?>"><?php echo e($sd->development_name); ?> </a>
                             </li>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </ul>
                 </div>
                 <!-- end footer Our services -->

                 <!-- start footer Do More With -->
                 
                 
                 <!-- End footer Do More With -->

                 <!-- start footer contact info -->
                 <div class="footer_bottom-item" <?php if ($_SERVER['REQUEST_URI'] != '/portfolio') {
                     echo 'data-aos="fade-up"';
                 } ?>>
                     <div class="bottom-item_title">
                         CONTACT INFO
                     </div>
                     <?php $__currentLoopData = $footer_forth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ffth): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <div class="bottom-item_subtitle">
                             <a class="footer_text" href="<?php echo e($ffth->link); ?>"
                                 target="_blank"><?php echo e($ffth->description); ?></a>
                         </div>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <?php $__currentLoopData = $contact_media_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <div class="bottom-item_subtitle">
                             <i class="<?php echo e($cmi->code); ?>"></i>
                             <a class="footer_text_2" href="<?php echo e($cmi->title_link); ?>" target="_blank">
                                 <?php echo e($cmi->title); ?>

                             </a><br>
                         </div>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                     
                     
                     <div class="item_messan-wrpper service_icone_set ">
                         <?php $__currentLoopData = $footer_fifth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fifth): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <a href="<?php echo e($fifth->link); ?>" class="item_messan-link" target="_blank">
                                 <img src="<?php echo e(URL('upload/' . $fifth->image)); ?>" width="22" height="25"
                                     alt="">
                             </a>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </div>

                     
                 </div>
                 <!-- End footer contact info -->
             </div>
         </div>
     </div>
     <div class="container">
         <div class="footer_right">
             © 2022 , All right reserved
         </div>
     </div>
 </footer>

 
 <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

 <!-- Link counter js file -->
 <script type="text/javascript" src="<?php echo e(url('asset/js/html.js')); ?>"></script>

 
 
 <script type="text/javascript" src="https://smav.com.ua/js/rellax.min.js"></script>
 <script  type="text/javascript" src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
 <script type="text/javascript" src="https://smav.com.ua/js/libs.min.js"></script>
 <script type="text/javascript" src="https://smav.com.ua/js/main.js"></script>

 
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.3/jquery.validate.min.js"></script>

 
 <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
 <script type="text/javascript" src="<?php echo e(url('asset/js/slick.js')); ?>"></script>

 
 <script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>

 </body>

 </html>
<?php /**PATH D:\xampp\htdocs\laravel\Dioneapps_f_b\resources\views/user_footer.blade.php ENDPATH**/ ?>